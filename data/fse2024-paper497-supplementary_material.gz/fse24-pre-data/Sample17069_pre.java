package com.jigen.ant;
class Sample3857_method
{
    boolean func()
    {
        return false;
    }
}
