    public Throwable getCause() {
        return this.cause;
    }