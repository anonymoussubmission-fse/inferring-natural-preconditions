    public void join(Party parent, Party child) {
        try {
            parent.add(child);
            setChanged();
            notifyObservers(child);
        } catch (NullPointerException e) {
            System.err.println("GameState.join(): parent=" + parent + " " + "child=" + child);
            e.printStackTrace(System.err);
        }
    }