package de.huxhorn.lilith.data.logging.xml;
import javax.xml.stream.XMLStreamReader;
class Sample6247_method
{
    boolean func(XMLStreamReader reader)
    {
        int type;
        try {
            type = reader.getEventType();
        } catch (          NullPointerException e) {
            return true;
        }
        return false;
    }
}
