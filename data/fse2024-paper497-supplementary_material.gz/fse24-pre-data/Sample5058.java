    public void stockTypeFilter(String val) {
        this.m_stockTypeFilter = val;
    }