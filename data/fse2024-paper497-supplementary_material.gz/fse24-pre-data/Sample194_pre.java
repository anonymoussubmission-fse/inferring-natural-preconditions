package macaw.util;
class Sample19246_method
{
    boolean func()
    {
        return false;
    }
}
