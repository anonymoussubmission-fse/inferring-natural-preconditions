    public String getTgtFrame() {
        if (this.tgtFrame == null)
            return "";
        return this.tgtFrame;
    }