    public void deliver(InternalScheduledEvent paramInternalScheduledEvent) {
        this.queue.add(paramInternalScheduledEvent);
    }