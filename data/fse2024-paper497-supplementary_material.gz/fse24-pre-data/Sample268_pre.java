package macaw.businessLayer;
class Sample20895_method extends OntologyTerm
{
    boolean func(boolean paramBoolean)
    {
        return false;
    }
}
