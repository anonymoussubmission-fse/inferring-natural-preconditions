    public void prompt(String msg) {
        log.debug("Prompt: " + msg);
    }