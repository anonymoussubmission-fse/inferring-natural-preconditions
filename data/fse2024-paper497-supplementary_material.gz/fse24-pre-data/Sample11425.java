    public void setLinksDirty(boolean linksDirty) {
        set1stProperty(16L, linksDirty);
    }