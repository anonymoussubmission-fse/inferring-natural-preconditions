package corina.formats;
class Sample79_method
{
    boolean func()
    {
        return false;
    }
}
