    public static LoggingProto.Throwable convert(ThrowableInfo throwableInfo) {
        if (throwableInfo == null) {
            return null;
        }
        LoggingProto.Throwable.Builder builder = LoggingProto.Throwable.newBuilder();
        {
            String name = throwableInfo.getName();
            if (name != null) {
                builder.setThrowableClass(name);
            }
        }
        {
            String message = throwableInfo.getMessage();
            if (message != null) {
                builder.setMessage(message);
            }
        }
        {
            int omittedElements = throwableInfo.getOmittedElements();
            if (omittedElements > 0) {
                builder.setOmittedElements(omittedElements);
            }
        }
        {
            ThrowableInfo[] suppressed = throwableInfo.getSuppressed();
            if (suppressed != null) {
                for (ThrowableInfo current : suppressed) {
                    if (current != null) {
                        builder.addSuppressed(convert(current));
                    }
                }
            }
        }
        {
            ThrowableInfo cause = throwableInfo.getCause();
            if (cause != null) {
                builder.setCause(convert(cause));
            }
        }
        {
            ExtendedStackTraceElement[] stackTrace = throwableInfo.getStackTrace();
            if (stackTrace != null) {
                for (ExtendedStackTraceElement current : stackTrace) {
                    if (current != null) {
                        builder.addStackTraceElement(convert(current));
                    }
                }
            }
        }
        return builder.build();
    }