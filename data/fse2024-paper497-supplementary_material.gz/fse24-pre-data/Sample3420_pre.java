package org.petsoar.actions.order;
class Sample3654_method extends EditOrder
{
    boolean func()
    {
        return false;
    }
}
