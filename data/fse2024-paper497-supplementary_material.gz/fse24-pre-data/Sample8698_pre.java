package jigl.gui;
import jigl.signal.BadSignalException;
class Sample38451_method extends SignalCanvas
{
    Sample38451_method()
    {
    }
    Sample38451_method(jigl.signal.Signal sig) throws BadSignalException {
        super(sig);
    }
    boolean func()
    {
        if (image == null)
            return true;
        return false;
    }
}
