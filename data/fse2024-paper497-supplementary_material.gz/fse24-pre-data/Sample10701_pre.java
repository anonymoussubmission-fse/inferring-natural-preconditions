package org.apache.poi.sl.draw.binding;
class Sample18797_method
{
    boolean func(CTAdjustHandleList value)
    {
        return false;
    }
}
