    public void query(Interval interval, Collection foundItems) {
        this.root.addAllItemsFromOverlapping(interval, foundItems);
    }