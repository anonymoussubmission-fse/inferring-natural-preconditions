    public Boolean getOperativerNutzen() {
        return this.operativerNutzen;
    }