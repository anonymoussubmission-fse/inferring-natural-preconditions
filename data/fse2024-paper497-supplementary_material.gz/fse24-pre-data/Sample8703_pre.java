package jigl.image;
class Sample39004_method extends ColorHistogram
{
    Sample39004_method(ColorImage image)
    {
        super(image);
    }       Sample39004_method(ColorImage image, int rbits, int gbits, int bbits)
    {
        super(image                     );
    }
    boolean func(ColorImage image, int rbits, int gbits, int bbits)
    {
        return false;
    }
}
