    public void configureCharacterSets() {
        throw (CJOperationNotSupportedException) ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
    }