package org.apache.poi.ddf;
import org.apache.poi.util.HexDump;
class Sample18183_method extends EscherComplexProperty
{
    Sample18183_method(short id, byte[] complexData)
    {
        super(id, complexData);
    }
    boolean func()
    {
        String dataStr;
        try {
            dataStr = HexDump.toHex(     _complexData, 32);
        } catch (          NullPointerException e) {
            return true;
        }
        return false;
    }
}
