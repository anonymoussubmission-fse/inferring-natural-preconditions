package org.asphodel.search;
class Sample4381_method
{
    boolean func()
    {
        return false;
    }
}
