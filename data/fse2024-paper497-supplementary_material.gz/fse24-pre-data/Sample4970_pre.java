package com.werken.saxpath;
class Sample25558_method
{
    boolean func()
    {
        return false;
    }
}
