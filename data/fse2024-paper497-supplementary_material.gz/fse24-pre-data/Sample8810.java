    public void set(short value) {
        this.memory.set(this.address, value);
    }