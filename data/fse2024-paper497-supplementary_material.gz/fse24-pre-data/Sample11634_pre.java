package ghm.follow.io;
import java.io.PrintStream;
class Sample4399_method extends PrintStreamDestination
{
    Sample4399_method(PrintStream printStream)
    {
        super(printStream);
    }
    boolean func()
    {
        return false;
    }
}
