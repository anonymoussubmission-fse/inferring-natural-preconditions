package org.asphodel.search;
class Sample4395_method extends QueryCommand
{
    Sample4395_method(String queryString)
    {
        super(queryString);
    }
    boolean func(int startIndex)
    {
        return false;
    }
}
