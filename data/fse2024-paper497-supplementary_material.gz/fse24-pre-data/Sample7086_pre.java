package com.lts.compare;
import java.lang.reflect.Field;
class Sample24484_method extends FieldCompareRecord
{
    Sample24484_method(Field paramField, Object paramObject1, Object paramObject2)
    {
        super(paramField, paramObject1, paramObject2);
    }
    boolean func(boolean paramBoolean)
    {
        if (     myField == null)
            return true;
        return false;
    }
}
