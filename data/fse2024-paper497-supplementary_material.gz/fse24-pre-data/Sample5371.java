    public static LoggerContext convert(LoggingProto.LoggerContext loggerContext) {
        if (loggerContext == null) {
            return null;
        }
        LoggerContext result = new LoggerContext();
        if (loggerContext.hasName()) {
            result.setName(loggerContext.getName());
        }
        if (loggerContext.hasBirthTime()) {
            result.setBirthTime(loggerContext.getBirthTime());
        }
        if (loggerContext.hasProperties()) {
            result.setProperties(convert(loggerContext.getProperties()));
        }
        return result;
    }