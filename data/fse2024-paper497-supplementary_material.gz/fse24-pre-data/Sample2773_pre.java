package com.gbshape.dbe.struts.action;
import com.gbshape.dbe.struts.bean.DBDataBean;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
class Sample18370_method
{
    boolean func(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    {
        HttpSession session;
        try {
            if (request == null)
                return true;
            session = request.getSession();
        } catch (          ClassCastException e) {
            return true;
        }
        Object var_b = session                           ;
        if (!(var_b instanceof DBDataBean))
            return true;
        return false;
    }
}
