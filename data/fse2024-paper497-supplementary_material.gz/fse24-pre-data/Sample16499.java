    public static String byteArrayToBase64(byte[] bb) {
        return _$23170(bb, false);
    }