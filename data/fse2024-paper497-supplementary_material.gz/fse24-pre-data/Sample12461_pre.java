package dk.statsbiblioteket.util;
class Sample9449_method extends Profiler
{
    Sample9449_method()
    {
    }
    Sample9449_method(int expectedTotal, int bpsSpan)
    {
    }
    boolean func()
    {
        long var_a;
        try {
            var_a = beat(  );
        } catch (          NullPointerException e) {
            return true;
        } catch (          ArrayIndexOutOfBoundsException e) {
            return true;
        }
        return false;
    }
}
