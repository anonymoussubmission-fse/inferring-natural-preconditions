    public void setType(Class<?> newType) {
        this.type = newType;
    }