    public int getActor() {
        return this.actor;
    }