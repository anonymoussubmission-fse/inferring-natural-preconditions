package org.apache.poi.sl.draw.binding;
class Sample18479_method
{
    boolean func(CTPercentage value)
    {
        return false;
    }
}
