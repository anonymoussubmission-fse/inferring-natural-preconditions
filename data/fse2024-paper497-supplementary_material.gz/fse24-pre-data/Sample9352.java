    protected void setInstructionPointer(int instructionPointer) {
        this.nextInstructionPointer = instructionPointer;
    }