package ch.bfh.egov.nutzenportfolio.tos;
class Sample10046_method
{
    boolean func(Integer nutzenkriteriumId)
    {
        return false;
    }
}
