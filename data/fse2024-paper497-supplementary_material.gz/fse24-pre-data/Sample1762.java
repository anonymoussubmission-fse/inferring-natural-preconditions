    public void startDocument() throws SAXException {
        SAXEvent saxEvent = new SAXEvent((byte) 4);
        this.events.add(saxEvent);
    }