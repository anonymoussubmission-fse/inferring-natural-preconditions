package de.huxhorn.lilith.data.access;
class Sample6091_method
{
    boolean func()
    {
        return false;
    }
}
