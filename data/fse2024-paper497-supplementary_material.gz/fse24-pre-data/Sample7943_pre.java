package com.vividsolutions.jts.index.bintree;
class Sample13429_method extends Bintree
{
    boolean func(Interval interval)
    {
        if (interval == null)
            return true;
        return false;
    }
}
