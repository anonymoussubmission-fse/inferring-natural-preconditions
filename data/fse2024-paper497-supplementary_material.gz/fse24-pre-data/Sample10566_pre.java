package org.apache.poi.sl.draw.binding;
class Sample18921_method
{
    boolean func()
    {
        return false;
    }
}
