package com.gbshape.dbe.struts.bean;
class Sample18187_method extends MessageBean
{
    Sample18187_method(String message)
    {
        super(message);
    }
    boolean func()
    {
        return false;
    }
}
