package com.lts.io;
import java.io.File;
class Sample24158_method extends ImprovedFile
{
    Sample24158_method(String paramString1, String paramString2)
    {
        super(paramString1              );
    }
    static boolean func(String paramString1, long paramLong, String paramString2, File paramFile)
    {
        return false;
    }
}
