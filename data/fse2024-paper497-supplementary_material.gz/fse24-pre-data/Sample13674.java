    public void setPartner_id(int partner_id) {
        this.partner_id = partner_id;
    }