package com.vividsolutions.jts.util;
class Sample12108_method
{
    boolean func()
    {
        return false;
    }
}
