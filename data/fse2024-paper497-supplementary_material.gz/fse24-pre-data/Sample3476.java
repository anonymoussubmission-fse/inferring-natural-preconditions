    public void savePet(Pet pet) {
        this.persistenceManager.save(pet);
    }