    public boolean hasArguments() {
        return (this.arguments != null);
    }