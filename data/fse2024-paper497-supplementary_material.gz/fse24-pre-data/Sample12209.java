    public int getMessageType() {
        return this.messageType;
    }