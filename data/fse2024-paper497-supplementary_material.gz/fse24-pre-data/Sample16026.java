    public String getEncodingStyle() {
        return this.encodingStyle;
    }