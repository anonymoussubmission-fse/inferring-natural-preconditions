    protected void setParseText(String parseText) {
        this.parseText = parseText;
    }