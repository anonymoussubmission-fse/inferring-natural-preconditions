package org.apache.poi.sl.draw.geom;
import org.apache.poi.sl.draw.binding.CTAdjPoint2D;
class Sample19034_method extends CurveToCommand
{
    Sample19034_method(CTAdjPoint2D pt1, CTAdjPoint2D pt2, CTAdjPoint2D pt3)
    {
        super(pt1, pt2, pt3);
    }
    boolean func(CTAdjPoint2D pt1, CTAdjPoint2D pt2, CTAdjPoint2D pt3)
    {
        if (pt1 == null)
            return true;
        if (pt2 == null)
            return true;
        if (pt3 == null)
            return true;
        return false;
    }
}
