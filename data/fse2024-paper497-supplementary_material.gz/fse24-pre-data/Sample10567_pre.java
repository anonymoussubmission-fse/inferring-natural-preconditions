package org.apache.poi.sl.draw.binding;
class Sample18611_method extends CTColorMRU
{
    boolean func()
    {
        return false;
    }
}
