package macaw.system;
import javax.swing.JOptionPane;
class Sample19298_method
{
    boolean func(String paramString)
    {
        try {
            JOptionPane.showMessageDialog(null, 1);
        } catch (java.awt.HeadlessException e) {
            return true;
        }
        return false;
    }
}
