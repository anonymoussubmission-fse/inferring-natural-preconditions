package de.huxhorn.lilith.log4j.xml;
import de.huxhorn.sulky.buffers.AppendOperation;
import java.io.File;
class Sample4574_method extends Log4jImportCallable
{
    Sample4574_method(File inputFile, AppendOperation                             buffer)
    {
        super(inputFile, buffer);
    }
    boolean func()
    {
        return false;
    }
}
