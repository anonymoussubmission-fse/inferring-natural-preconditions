package org.jsecurity.ri.authz;
class Sample14450_method
{
    boolean func()
    {
        return false;
    }
}
