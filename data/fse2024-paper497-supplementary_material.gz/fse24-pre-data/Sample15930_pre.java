package com.ibm.wsdl;
import javax.wsdl.Operation;
class Sample13157_method extends PortTypeImpl
{
    boolean func(Operation operation)
    {
        if (     operations == null)
            return true;
        try {
            this.operations.add(operation);
        } catch (java.util.ConcurrentModificationException e) {
            return true;
        }
        return false;
    }
}
