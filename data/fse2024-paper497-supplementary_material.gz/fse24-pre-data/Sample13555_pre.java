package org.javathena.conf;
class Sample26052_method
{
    boolean func()
    {
        return false;
    }
}
