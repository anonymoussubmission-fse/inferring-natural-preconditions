package com.werken.saxpath;
class Sample25509_method extends Token
{
    Sample25509_method(int tokenType, String parseText, int tokenBegin, int tokenEnd)
    {
        super(tokenType, parseText, tokenBegin, tokenEnd);
    }
    boolean func(int tokenEnd)
    {
        return false;
    }
}
