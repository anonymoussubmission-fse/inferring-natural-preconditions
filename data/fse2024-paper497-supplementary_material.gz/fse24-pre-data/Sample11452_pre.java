package org.apache.poi.sl.draw.binding;
class Sample18899_method extends CTSRgbColor
{
    boolean func()
    {
        if (     egColorTransform == null)
            return true;
        return false;
    }
}
