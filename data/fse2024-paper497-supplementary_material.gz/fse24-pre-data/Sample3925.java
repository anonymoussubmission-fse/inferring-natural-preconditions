    public float getY() {
        return this.y;
    }