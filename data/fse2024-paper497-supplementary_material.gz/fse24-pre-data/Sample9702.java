    public Color getBackground() {
        return this.background;
    }