package com.lts.swing;
import java.awt.Insets;
class Sample23986_method
{
    Sample23986_method(int paramInt1, int paramInt2, int paramInt3, int paramInt4, double paramDouble1, double paramDouble2, int paramInt5, int paramInt6, Insets paramInsets, int paramInt7, int paramInt8)
    {
    }
    boolean func()
    {
        return false;
    }
}
