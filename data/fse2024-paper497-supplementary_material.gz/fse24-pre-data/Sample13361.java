    public boolean add(HttpServletRequest request, DynaActionForm form, ActionMessages errors, ActionMessages messages) {
        String name = (String) form.get("name");
        String beschreibung = (String) form.get("beschreibung");
        this.logger.debug("name=" + name);
        this.logger.debug("beschreibung=" + beschreibung);
        if (name == null || name.length() == 0) {
            errors.add("name", new ActionMessage("errors.required", "Name"));
            return false;
        }
        if (beschreibung == null || beschreibung.length() == 0) {
            errors.add("beschreibung", new ActionMessage("errors.required", "Beschreibung"));
            return false;
        }
        StrategischesZiel sz = createStrategischesZiel(request, form);
        if (this.dao.getByName(sz) != null) {
            messages.add("org.apache.struts.action.GLOBAL_MESSAGE", new ActionMessage("errors.duplicate", "Strategisches Ziel"));
            return false;
        }
        this.dao.insert(sz);
        return true;
    }