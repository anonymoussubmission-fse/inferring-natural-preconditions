package dk.statsbiblioteket.summa.common;
class Sample7367_method
{
    Sample7367_method(String id, String base, byte[] data)
    {
    }       Sample7367_method(String id, String base, byte[] data, long lastModified)
    {
    }
    boolean func()
    {
        return false;
    }
}
