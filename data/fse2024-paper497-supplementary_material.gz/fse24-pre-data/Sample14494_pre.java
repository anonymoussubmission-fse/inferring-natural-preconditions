package org.exolab.jms.util;
class Sample19047_method extends CommandLine
{
    boolean func(String name)
    {
        if (     _switches == null)
            return true;
        return false;
    }
}
