    public Pattern[] getUnionPatterns() {
        return null;
    }