    public void setDestinationPlayer(Offender paramOffender, boolean paramBoolean) {
        this.destinationPlayer = paramOffender;
        this.destinationPointTemporary = paramBoolean;
    }