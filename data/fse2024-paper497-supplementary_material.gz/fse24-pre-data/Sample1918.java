    public Boolean isList() {
        return this.list;
    }