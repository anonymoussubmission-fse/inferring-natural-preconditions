    public double getPriority() {
        return 0.5D;
    }