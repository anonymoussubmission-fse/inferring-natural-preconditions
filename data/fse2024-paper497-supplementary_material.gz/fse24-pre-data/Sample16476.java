    public String[][] getArr2params() {
        return this.arr2params;
    }