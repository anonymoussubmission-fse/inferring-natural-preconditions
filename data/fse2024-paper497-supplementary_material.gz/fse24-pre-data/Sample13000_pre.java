package state;
class Sample17135_method
{
    boolean func()
    {
        return false;
    }
}
