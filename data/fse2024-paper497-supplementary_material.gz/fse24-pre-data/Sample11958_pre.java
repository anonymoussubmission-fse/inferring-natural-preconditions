package visu.handball.moves.model;
class Sample18537_method extends ColorModel
{
    boolean func()
    {
        try {
            fireModelChanged();
        } catch (          ClassCastException e) {
            return true;
        } catch (          NullPointerException e) {
            return true;
        }
        return false;
    }
}
