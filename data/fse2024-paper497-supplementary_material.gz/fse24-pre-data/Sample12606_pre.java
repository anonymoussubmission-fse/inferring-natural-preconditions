package dk.statsbiblioteket.summa.common.lucene.distribution;
import java.io.UnsupportedEncodingException;
class Sample6794_method extends TermValueConverter
{
    boolean func(byte[] buffer, int length)
    {
        String content;
        try {
            content = new String(buffer, "utf-8");
        } catch (UnsupportedEncodingException e) {
            return true;
        }
        int pos = content.lastIndexOf(DELIMITER);
        String var_b;
        try {
            var_b = content.substring(   pos);
        } catch (          StringIndexOutOfBoundsException e) {
            return true;
        }
        return false;
    }
}
