package jigl.signal;
class Sample38820_method extends DiscreteSignal
{
    Sample38820_method()
    {
    }
    Sample38820_method(int x)
    {
        super(x);
    }
    Sample38820_method(short[] data)
    {
    }
    boolean func(int x, int value)
    {
        if (x < 0 || x >=      length)
            return true;
        return false;
    }
}
