package org.dom4j.io;
class Sample19287_method
{
    boolean func()
    {
        return false;
    }
}
