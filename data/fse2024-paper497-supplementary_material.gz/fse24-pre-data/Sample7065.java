    public static SimpleGridBagConstraint buttonConstraint(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
        Insets insets = new Insets(paramInt4, paramInt3, paramInt4, paramInt3);
        return buttonConstraint(paramInt1, paramInt2, insets);
    }