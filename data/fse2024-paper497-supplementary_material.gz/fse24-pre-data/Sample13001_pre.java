package state;
class Sample17042_method
{
    Sample17042_method(int actor, int target, int messagetype, String text)
    {
    }       Sample17042_method()
    {
    }
    boolean func()
    {
        return false;
    }
}
