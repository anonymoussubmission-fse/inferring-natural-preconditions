package ch.bfh.egov.nutzenportfolio.tos;
class Sample9956_method
{
    boolean func(Double resultat)
    {
        return false;
    }
}
