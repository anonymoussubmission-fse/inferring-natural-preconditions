package osa.ora.server.beans;
class Sample21062_method
{
    boolean func(int toUserId)
    {
        return false;
    }
}
