    public Integer getHours() {
        return this.hours;
    }