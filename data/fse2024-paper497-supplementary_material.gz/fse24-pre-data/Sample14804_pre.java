package org.exolab.jms.client.net;
import org.exolab.jms.net.proxy.Delegate;
class Sample19950_method extends JmsSessionStubImpl__Proxy
{
    Sample19950_method(Delegate delegate)
    {
        super(delegate);
    }
    boolean func()
    {
        try {
            invoke(COMMIT_ffffffff8271f49a, null,  2106461030L);
        } catch (Throwable exception) {
            return true;
        }
        return false;
    }
}
