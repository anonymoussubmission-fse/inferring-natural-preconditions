package de.huxhorn.lilith.data.logging.logback;
class Sample6392_method extends TransformingEncoder
{
    Sample6392_method(boolean inSameThread)
    {
        super(inSameThread);
    }
    boolean func()
    {
        return false;
    }
}
