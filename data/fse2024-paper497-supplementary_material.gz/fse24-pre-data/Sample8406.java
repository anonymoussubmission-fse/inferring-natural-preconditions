    protected Signal apply(DiscreteSignal signal) {
        return apply(signal, new ROI(0, signal.length() - 1));
    }