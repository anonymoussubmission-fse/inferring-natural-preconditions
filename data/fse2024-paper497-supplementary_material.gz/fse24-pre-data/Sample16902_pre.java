package org.asphodel.search;
import org.apache.lucene.document.Document;
class Sample4372_method extends FtrRecord
{
    Sample4372_method(Document document, float score)
    {
        super(document, score);
    }
    boolean func()
    {
        if (     document == null)
            return true;
        return false;
    }
}
