package com.lts.swing.table;
class Sample23632_method extends DynamicTableModel
{
    boolean func()
    {
        if (     myData == null)
            return true;
        return false;
    }
}
