    public boolean equals(Object p_other) {
        if (this == p_other)
            return true;
        if (p_other == null)
            return false;
        ComboLeg l_theOther = (ComboLeg) p_other;
        if (this.m_conId != l_theOther.m_conId || this.m_ratio != l_theOther.m_ratio || this.m_openClose != l_theOther.m_openClose || this.m_shortSaleSlot != l_theOther.m_shortSaleSlot)
            return false;
        if (Util.StringCompareIgnCase(this.m_action, l_theOther.m_action) != 0 || Util.StringCompareIgnCase(this.m_exchange, l_theOther.m_exchange) != 0 || Util.StringCompareIgnCase(this.m_designatedLocation, l_theOther.m_designatedLocation) != 0)
            return false;
        return true;
    }