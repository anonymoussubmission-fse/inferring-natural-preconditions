package fr.unice.gfarce.identity;
import java.util.Calendar;
class Sample38618_method
{
    Sample38618_method(String nom, String prenom, String sex, String email, Calendar date_naissance, String diplome, String photo, String nationalite, int bourse, int acceptation, Formation f)
    {
    }
    boolean func(int bourse)
    {
        return false;
    }
}
