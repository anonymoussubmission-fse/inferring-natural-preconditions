package jigl.image;
class Sample39137_method
{
    boolean func()
    {
        return false;
    }
}
