package com.lts.application.swing;
import com.lts.application.ApplicationRepository;
class Sample21846_method extends ApplicationWindowRepositoryListener
{
    Sample21846_method(ApplicationContentPanel paramApplicationContentPanel)
    {
        super(paramApplicationContentPanel);
    }
    boolean func(ApplicationRepository paramApplicationRepository)
    {
        if (     panel == null)
            return true;
        return false;
    }
}
