    public void simpleValue(StringBuffer toAppendTo, Object value) {
        synchronized (CellDateFormatter.class) {
            if (SIMPLE_DATE == null || !SIMPLE_DATE.EXCEL_EPOCH_CAL.equals(this.EXCEL_EPOCH_CAL))
                SIMPLE_DATE = new CellDateFormatter("mm/d/y");
        }
        SIMPLE_DATE.formatValue(toAppendTo, value);
    }