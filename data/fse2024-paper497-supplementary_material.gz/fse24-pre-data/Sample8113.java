    public void flip() {
        this.elt[0].flip();
        this.elt[1].flip();
    }