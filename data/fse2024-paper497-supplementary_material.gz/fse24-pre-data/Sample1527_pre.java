package org.dom4j.tree;
import org.dom4j.Element;
class Sample19954_method extends DefaultText
{
    Sample19954_method(Element parent, String text)
    {
        super(        text);
    }
    boolean func(Element parent)
    {
        return false;
    }
}
