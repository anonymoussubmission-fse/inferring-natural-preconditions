    public void addBulletedList(ArrayList<String> paramArrayList) {
        if (paramArrayList.size() == 0)
            return;
        this.buffer.append("<ul>");
        for (String str : paramArrayList) {
            this.buffer.append("<li>");
            this.buffer.append(str);
            this.buffer.append("</li>");
        }
        this.buffer.append("</ul>");
    }