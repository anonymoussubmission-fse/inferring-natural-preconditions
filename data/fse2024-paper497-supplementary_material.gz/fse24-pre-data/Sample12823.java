    public IndexChangeEvent(IndexChanger sender, int[] removedDocIDs) {
        this.sender = sender;
        this.event = Event.documentsRemoved;
        this.removedDocIDs = removedDocIDs;
    }