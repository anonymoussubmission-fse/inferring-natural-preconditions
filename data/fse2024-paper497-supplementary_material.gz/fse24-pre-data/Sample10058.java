    public void setR(int value) {
        this.r = value;
    }