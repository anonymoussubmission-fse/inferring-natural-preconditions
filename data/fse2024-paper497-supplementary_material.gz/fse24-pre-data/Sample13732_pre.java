package org.javathena.core.data;
class Sample25608_method
{
    boolean func(int id)
    {
        return false;
    }
}

}
