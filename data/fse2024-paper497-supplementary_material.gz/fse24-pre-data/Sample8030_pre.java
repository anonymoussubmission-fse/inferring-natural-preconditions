package com.vividsolutions.jts.io;
class Sample11759_method extends ByteArrayInStream
{
    Sample11759_method(byte[] buffer)
    {
        super(buffer);
    }
    boolean func(byte[] buffer)
    {
        return false;
    }
}
