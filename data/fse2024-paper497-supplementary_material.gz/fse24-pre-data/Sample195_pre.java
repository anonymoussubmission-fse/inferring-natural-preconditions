package macaw;
class Sample19393_method
{
    static boolean func(String paramString1, String paramString2, String paramString3)
    {
        return false;
    }
}
