    public void transform(float[] x, float[] y, int offset, int count) throws IllegalArgumentException {
        if (x.length != y.length)
            throw new IllegalArgumentException();
        float a = 0;
        float b = 0;
        final int lastIndex = Math.min(x.length, offset + count);
        for (int i = offset; i < lastIndex; ++i) {
            a = x[i];
            b = y[i];
            x[i] = (a * cosang) + (b * sinang);
            y[i] = -(a * sinang) + (b * cosang);
        }
    }