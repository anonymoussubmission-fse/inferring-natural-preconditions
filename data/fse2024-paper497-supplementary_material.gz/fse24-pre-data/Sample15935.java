    public List getNativeAttributeNames() {
        return this.nativeAttributeNames;
    }