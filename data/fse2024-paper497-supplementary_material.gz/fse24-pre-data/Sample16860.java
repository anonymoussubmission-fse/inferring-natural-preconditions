    public void setIndex(int index) {
        this.index = index;
    }