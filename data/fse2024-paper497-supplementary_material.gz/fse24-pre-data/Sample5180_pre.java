package fr.unice.gfarce.dao;
class Sample38776_method extends DaoException
{
    Sample38776_method(int code)
    {
        super(code);
    }
    boolean func(int code)
    {
        return false;
    }
}
