package osa.ora.server.beans;
class Sample21091_method
{
    boolean func()
    {
        return false;
    }
}
