package com.mysql.cj.xdevapi;
import com.mysql.cj.result.Field;
class Sample19053_method extends ColumnImpl
{
    Sample19053_method(Field f)
    {
        super(f);
    }
    boolean func()
    {
        String var_a;
        try {
            var_a = this.field.getName();
        } catch (          StringIndexOutOfBoundsException e) {
            return true;
        } catch (com.mysql.cj.exceptions.WrongArgumentException e) {
            return true;
        } catch (          NullPointerException e) {
            return true;
        }
        return false;
    }
}
