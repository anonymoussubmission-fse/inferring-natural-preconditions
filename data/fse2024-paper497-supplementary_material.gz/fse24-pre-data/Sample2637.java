    public void setThirdPartyProductInfo(ThirdPartyProductInfo paramThirdPartyProductInfo) {
        this.thirdPartyProductInfo = paramThirdPartyProductInfo;
    }