package com.lts.caloriecount.ui.dayview;
class Sample25047_method
{
    boolean func()
    {
        return false;
    }
}
