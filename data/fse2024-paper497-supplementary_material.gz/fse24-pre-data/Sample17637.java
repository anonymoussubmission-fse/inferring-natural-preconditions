    public Properties get(Object key) {
        return this.map.get(key);
    }