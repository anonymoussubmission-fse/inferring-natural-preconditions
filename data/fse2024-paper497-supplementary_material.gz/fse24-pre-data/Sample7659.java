    protected void initialize() {
        this.myThread = new Thread(this);
        this.myQueueToNext = new HashMap<SharedQueue, ScheduledEvent>();
        this.myEvents = new ArrayList<ScheduledEvent>();
    }