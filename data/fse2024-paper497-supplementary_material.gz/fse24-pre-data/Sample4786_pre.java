package com.mysql.cj.jdbc.ha;
import java.util.Properties;
class Sample21226_method extends MultiHostMySQLConnection
{
    Sample21226_method(MultiHostConnectionProxy proxy)
    {
        super(proxy);
    }
    boolean func(Properties properties)
    {
        com.mysql.cj.jdbc.JdbcConnection var_a;
        try {
            var_a = getActiveMySQLConnection();
        } catch (          NullPointerException e) {
            return true;
        }
        return false;
    }
}
