    public boolean isSignificant(float score, int overlap) {
        if (overlap == 0)
            return false;
        return (score > 0.25F);
    }