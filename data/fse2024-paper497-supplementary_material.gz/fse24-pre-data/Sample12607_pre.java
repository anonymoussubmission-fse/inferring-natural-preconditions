package dk.statsbiblioteket.summa.common.lucene.search;
class Sample6920_method extends BinaryCollector
{
    Sample6920_method(int maxHits)
    {
        super(maxHits);
    }
    boolean func()
    {
        return false;
    }
}
