package com.ibm.wsdl;
class Sample13696_method
{
    boolean func()
    {
        return false;
    }
}
