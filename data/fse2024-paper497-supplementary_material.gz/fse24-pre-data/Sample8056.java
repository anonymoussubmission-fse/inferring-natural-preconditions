    public static String bytesToHex(byte[] bytes) {
        return toHex(bytes);
    }