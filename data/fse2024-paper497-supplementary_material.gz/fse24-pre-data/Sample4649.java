    public Field(LazyString databaseName, LazyString tableName, LazyString originalTableName, LazyString columnName, LazyString originalColumnName, long length, int mysqlTypeId, short colFlag, int colDecimals, int collationIndex, String encoding, MysqlType mysqlType) {
        this.databaseName = databaseName;
        this.tableName = tableName;
        this.originalTableName = originalTableName;
        this.columnName = columnName;
        this.originalColumnName = originalColumnName;
        this.length = length;
        this.colFlag = colFlag;
        this.colDecimals = colDecimals;
        this.mysqlTypeId = mysqlTypeId;
        this.collationIndex = collationIndex;
        this.encoding = "UnicodeBig".equals(encoding) ? "UTF-16" : encoding;
        if (mysqlType == MysqlType.JSON)
            this.encoding = "UTF-8";
        this.mysqlType = mysqlType;
        adjustFlagsByMysqlType();
    }