    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }