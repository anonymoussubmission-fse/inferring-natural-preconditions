    public Complex div(double a) {
        x /= (float) a;
        y /= (float) a;
        return this;
    }