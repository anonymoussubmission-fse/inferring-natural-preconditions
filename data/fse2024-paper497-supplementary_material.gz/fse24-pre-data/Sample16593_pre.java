package org.jsecurity.ri.web.support;
class Sample14391_method extends DefaultWebSessionFactory
{
    boolean func(boolean validateRequestOrigin)
    {
        return false;
    }
}
