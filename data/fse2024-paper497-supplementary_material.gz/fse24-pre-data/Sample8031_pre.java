package com.vividsolutions.jts.math;
class Sample14114_method
{
    static boolean func(double x1, double x2)
    {
        return false;
    }
}
