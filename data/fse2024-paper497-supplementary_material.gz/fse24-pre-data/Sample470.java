    public FMSettingMessageBuilder withThreadState(FMSettingMessage.ThreadState threadState) {
        this.fmSettingMessage.setThread_state(threadState);
        return this;
    }