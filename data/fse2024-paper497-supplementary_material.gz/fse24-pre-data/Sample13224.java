    public void setEintrittszeitpunktId(Integer eintrittszeitpunktId) {
        this.logger.debug(eintrittszeitpunktId);
        this.eintrittszeitpunktId = eintrittszeitpunktId;
    }