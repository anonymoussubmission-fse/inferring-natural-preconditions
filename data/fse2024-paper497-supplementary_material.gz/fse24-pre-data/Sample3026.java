    public BigDecimal getPercent() {
        return this.percent;
    }