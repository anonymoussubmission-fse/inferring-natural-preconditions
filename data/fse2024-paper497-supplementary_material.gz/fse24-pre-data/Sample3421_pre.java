package org.petsoar.security;
import java.util.StringTokenizer;
import javax.servlet.FilterConfig;
class Sample3605_method
{
    boolean func(FilterConfig filterConfig)
    {
        if (filterConfig == null)
            return true;
        String ignoreExtensions = filterConfig.getInitParameter("ignoreExtensions");
        StringTokenizer st;
        try {
            st = new StringTokenizer(ignoreExtensions      );
        } catch (          NullPointerException e) {
            return true;
        }
        return false;
    }
}
