package org.exolab.jms.selector.parser;
import java.io.InputStream;
class Sample18947_method extends SelectorLexer
{
    Sample18947_method(InputStream in)
    {
        super(in);
    }
    static              boolean func()
    {
        return false;
    }
}
