package net.kencochrane.a4j.beans;
class Sample2479_method
{
    boolean func()
    {
        return false;
    }
}
