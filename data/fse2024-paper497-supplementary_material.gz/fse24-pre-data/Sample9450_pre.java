package net.virtualinfinity.atrobots.gui.renderers;
import java.awt.Graphics2D;
import net.virtualinfinity.atrobots.snapshots.RobotSnapshot;
class Sample37972_method
{
    boolean func(Graphics2D g2d, RobotSnapshot robotSnapshot)
    {
        double var_b;
        try {
            var_b = robotSnapshot.getX();
        } catch (          NullPointerException e) {
            return true;
        }
        return false;
    }
}
