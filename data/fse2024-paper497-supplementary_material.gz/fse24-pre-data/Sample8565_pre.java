package jigl.image.ops;
import jigl.image.RealColorImage;
class Sample39723_method extends Dither
{
    Sample39723_method(RealColorImage paletteImage)
    {
        super(paletteImage);
    }
    static boolean func(String[] arg)
    {
        return false;
    }
}
