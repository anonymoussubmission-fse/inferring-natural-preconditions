    public void fireDelete(int paramInt, Object paramObject) {
        ListEvent listEvent = new ListEvent(ListEvent.EventType.Delete, paramInt, paramObject);
        fire(listEvent);
    }