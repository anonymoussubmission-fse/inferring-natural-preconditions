    public boolean isBorderOpaque() {
        return (this.innerThickness == 0 && this.thickness > 0 && this.borderColor != null);
    }