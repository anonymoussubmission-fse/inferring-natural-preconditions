    public void setConnected(boolean conned) {
        this.connected = conned;
    }