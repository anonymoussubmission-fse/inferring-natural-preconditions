package jigl.image.ops;
import jigl.image.ColorImage;
import jigl.image.GrayImage;
class Sample39699_method extends PoissonNoise
{
    boolean func(ColorImage image)
    {
        if (image == null)
            return true;
        GrayImage var_b = image.plane(0);
        jigl.image.Image var_f;
        try {
            var_f = apply(var_b       );
        } catch (          ArrayIndexOutOfBoundsException e) {
            return true;
        } catch (          NullPointerException e) {
            return true;
        }
        try {
            image.setPlane(0, (GrayImage) var_f);
        } catch (          NullPointerException e) {
            return true;
        }
        return false;
    }
}
