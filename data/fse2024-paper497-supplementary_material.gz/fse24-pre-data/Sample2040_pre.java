package com.facebook.api.schema;
class Sample16121_method
{
    boolean func()
    {
        return false;
    }
}
