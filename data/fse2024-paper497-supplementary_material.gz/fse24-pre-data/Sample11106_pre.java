package org.apache.poi.poifs.filesystem;
class Sample17020_method extends OPOIFSFileSystem
{
    boolean func()
    {
        DirectoryNode var_b;
        try {
            var_b = getRoot();
        } catch (          NullPointerException e) {
            return true;
        }
        return false;
    }
}
