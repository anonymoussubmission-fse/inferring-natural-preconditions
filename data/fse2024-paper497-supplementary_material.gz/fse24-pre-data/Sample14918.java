    public Response(Throwable exception) {
        this._exception = exception;
    }