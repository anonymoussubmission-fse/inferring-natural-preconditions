package com.facebook.api.schema;
class Sample15789_method extends GroupMembers
{
    boolean func(NotReplied value)
    {
        return false;
    }
}
