package jigl.image;
class Sample39122_method
{
    boolean func(ColorImage image)
    {
        return true;
    }
}
