package org.dom4j.io;
import java.io.ObjectInput;
class Sample19111_method
{
    boolean func(ObjectInput in)
    {
        if (in == null)
            return true;
        return false;
    }
}
