    public boolean isOverburn() {
        return this.overburn;
    }