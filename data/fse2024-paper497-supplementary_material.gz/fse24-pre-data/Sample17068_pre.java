package com.jigen;
import java.io.File;
import java.io.PrintStream;
class Sample3982_method extends WsfGenerator
{
    Sample3982_method(String jarOutputFileName)
    {
        super(jarOutputFileName);
    }
    boolean func(File file)
    {
        PrintStream ps;
        try {
            ps = new PrintStream(file);
        } catch (          NullPointerException e) {
            return true;
        } catch (java.io.FileNotFoundException e) {
            return true;
        }
        return false;
    }
}
