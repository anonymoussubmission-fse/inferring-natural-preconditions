package visu.handball.moves.views;
import visu.handball.moves.model.ColorModel;
class Sample18595_method extends FieldDrawer
{
    Sample18595_method(ColorModel paramColorModel)
    {
        super(paramColorModel);
    }
    boolean func(ColorModel paramColorModel)
    {
        try {
            createFieldShapes(paramColorModel);
        } catch (          NullPointerException e) {
            return true;
        }
        return false;
    }
}
