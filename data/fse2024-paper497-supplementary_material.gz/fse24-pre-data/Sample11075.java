    public void setReadIndex(int pos) {
        if (pos < 0 || pos >= this.count)
            throw new IndexOutOfBoundsException();
        this.pos = pos;
    }