package com.browsersoft.openhre.hl7.impl.config;
import com.browsersoft.openhre.hl7.api.parse.HL7CheckerState;
class Sample21096_method extends HL7FieldGivenDependingProcessorImpl
{
    boolean func(HL7CheckerState state)
    {
        if (state == null)
            return true;
        com.browsersoft.openhre.hl7.api.config.HL7Configuration var_b = state.getConfiguration();
        if (var_b == null)
            return true;
        com.browsersoft.openhre.hl7.api.config.HL7PatternsForCatchValues var_c = var_b.getPatterns();
        if (var_c == null)
            return true;
        String value = var_c.getValueForPattern(     from);
        boolean var_d = value.equals("");
        if (var_d)
            return true;
        return false;
    }
}
