    public int getCurrentIndex() throws IteratorException {
        int currIndex = 0;
        if (this.list != null) {
            currIndex = this.listIterator.nextIndex();
        } else {
            throw new IteratorException("");
        }
        return currIndex;
    }