package corina.map.layers;
import corina.map.Projection;
import java.awt.Graphics2D;
class Sample1226_method extends LegendLayer
{
    boolean func(Graphics2D g2, Projection r)
    {
        try {
            drawScale(g2, r);
        } catch (java.awt.HeadlessException e) {
            return true;
        }
        return false;
    }
}
