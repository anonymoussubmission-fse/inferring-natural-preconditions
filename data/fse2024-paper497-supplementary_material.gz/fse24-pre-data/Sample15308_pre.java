package com.browsersoft.openhre.hl7.impl.config;
class Sample21111_method
{
    boolean func(String description)
    {
        return false;
    }
}
