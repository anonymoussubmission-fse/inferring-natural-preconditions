    public void setHeaderForeground(Color c) {
        this.headerFg = c;
    }