package org.apache.poi.util;
class Sample17478_method extends LittleEndianCP950Reader
{
    Sample17478_method(byte[] data)
    {
        super(data);
    }       Sample17478_method(byte[] data, int offset, int length)
    {
        super(data                );
    }
    boolean func(int leading, int trailing)
    {
        return false;
    }
}
