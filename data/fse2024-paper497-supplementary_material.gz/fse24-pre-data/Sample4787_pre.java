package com.mysql.cj.protocol.x;
import com.mysql.cj.result.ValueFactory;
class Sample17898_method
{
    <T> boolean func(byte[] bytes, int offset, int length, ValueFactory    vf)
    {
        return false;
    }
}
