    public static SimpleGridBagConstraint verticalConstraint(int paramInt1, int paramInt2, Insets paramInsets) {
        return new SimpleGridBagConstraint(paramInt1, paramInt2, 1, 1, 0.0D, 1.0D, 10, 3, paramInsets, 0, 0);
    }