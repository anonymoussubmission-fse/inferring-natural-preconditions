package jigl.gui;
class Sample38400_method
{
    Sample38400_method()
    {
    }
    Sample38400_method(jigl.image.Image image)
    {
    }
    boolean func()
    {
        return false;
    }
}
