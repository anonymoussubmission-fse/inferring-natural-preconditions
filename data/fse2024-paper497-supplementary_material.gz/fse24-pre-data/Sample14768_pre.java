package org.exolab.jms.config;
class Sample20502_method extends GarbageCollectionConfiguration
{
    boolean func()
    {
        return false;
    }
}
