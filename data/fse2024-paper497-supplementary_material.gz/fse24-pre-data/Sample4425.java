    public synchronized boolean hasMoreTokens() {
        return (this.pos < this.sourceLength);
    }