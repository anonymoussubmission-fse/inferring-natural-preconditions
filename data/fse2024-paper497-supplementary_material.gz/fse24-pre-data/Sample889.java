    public boolean isOccupied() {
        return (this.occupier != null);
    }