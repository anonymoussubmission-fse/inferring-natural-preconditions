    protected static Class tryClass(String name) {
        Class<?> tempClass = null;
        try {
            if (name != null)
                tempClass = Class.forName(name.trim());
        } catch (ClassNotFoundException e) {
            return null;
        } catch (NoClassDefFoundError f) {
            return null;
        }
        return tempClass;
    }