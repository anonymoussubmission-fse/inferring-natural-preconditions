    public boolean add(Character character) {
        put(character.charValue());
        return true;
    }