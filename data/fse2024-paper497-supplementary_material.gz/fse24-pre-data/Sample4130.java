    protected void loadSample(File file) {
        if (file == null)
            return;
        try {
            Previewable s = null;
            try {
                log.trace("creating grid");
                s = new Grid(file.getPath());
                log.trace("done creating grid");
            } catch (WrongFiletypeException wfte) {
                s = new Sample(file.getPath());
            }
            showPreview(s.getPreview());
        } catch (WrongFiletypeException wfte) {
            wfte.printStackTrace();
            showPreview(new Preview.NotDendroDataPreview());
        } catch (IOException ioe) {
            ioe.printStackTrace();
            showPreview(new Preview.ErrorLoadingPreview(ioe));
        }
    }