package net.sf.jniinchi;
class Sample16865_method extends JniInchiBond
{
    Sample16865_method(JniInchiAtom atO, JniInchiAtom atT, int type, int stereo)
    {
        super(atO, atT, type, stereo);
    }
    Sample16865_method(JniInchiAtom atO, JniInchiAtom atT, INCHI_BOND_TYPE type)
    {
        super(atO, atT, type);
    }
    boolean func()
    {
        if (     type == null)
            return true;
        return false;
    }
}
