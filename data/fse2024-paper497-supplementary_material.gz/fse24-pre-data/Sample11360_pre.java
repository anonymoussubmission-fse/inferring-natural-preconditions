package org.apache.poi.hpsf;
class Sample19231_method
{
    boolean func(long id, long type, Object value)
    {
        return false;
    }
}
