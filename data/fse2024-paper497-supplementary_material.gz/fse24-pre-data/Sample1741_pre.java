package org.dom4j;
class Sample18759_method extends DocumentException
{
    Sample18759_method()
    {
    }       Sample18759_method(String message)
    {
    }
    Sample18759_method(String message, Throwable nestedException)
    {
    }
    boolean func()
    {
        return false;
    }
}
