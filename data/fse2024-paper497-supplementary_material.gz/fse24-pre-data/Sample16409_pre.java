package com.pmdesigns.jvc.tools;
import java.io.IOException;
class Sample3175_method extends JVCParserTokenManager
{
    Sample3175_method(SimpleCharStream stream)
    {
        super(stream);
    }
    boolean func(long old0, long active0)
    {
        try {
            if (     input_stream == null)
                return true;
            try {
                curChar = this.input_stream.readChar();
            } catch (          ArrayIndexOutOfBoundsException e) {
                return true;
            }
        } catch (IOException e) {
        }
        return false;
    }
}
