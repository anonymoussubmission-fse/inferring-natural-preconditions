package de.paragon.explorer;
import de.paragon.explorer.event.ExplorerFrameEventConverter;
import de.paragon.explorer.figure.ExplorerFigure;
class Sample18853_method extends Explorer
{
    Sample18853_method(Object object)
    {
        super(object);
    }
    static boolean func(ExplorerFigure explFig)
    {
        ExplorerFrameEventConverter var_a;
        try {
            var_a = new ExplorerFrameEventConverter(explFig);
        } catch (java.awt.HeadlessException e) {
            return true;
        }
        return false;
    }
}
