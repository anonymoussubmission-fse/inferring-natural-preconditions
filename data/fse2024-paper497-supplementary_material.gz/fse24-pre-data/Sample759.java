    public String toString() {
        return this.player + " aims at " + this.target;
    }