package com.facebook.api.schema;
class Sample16060_method
{
    boolean func(String value)
    {
        return false;
    }
}
