    protected void selectionChangedInvisibleList() {
        ObjectViewDialog objectViewDialog2 = getObjectViewDialog();
        objectViewDialog2.setRemoveButtonEnabled(false);
        objectViewDialog2.setAddButtonEnabled(true);
        objectViewDialog2.getVisibleList().clearSelection();
        objectViewDialog2.getInvisibleList().setSelectedIndex(getInvisibleAttributes().indexOf(getSelectedObject()));
        objectViewDialog2.getInvisibleList().ensureIndexIsVisible(getInvisibleAttributes().indexOf(getSelectedObject()));
        handleAttribute();
        ListBoxFigure liBoFi = getObjectToView();
        getExplorerFigure().getFocusManager().handleFocus((TextBoxFigure) ((ObjectModel) liBoFi.getModel()).getHeaderModel().getFigure(), false);
    }