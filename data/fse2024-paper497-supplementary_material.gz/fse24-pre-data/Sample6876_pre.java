package com.lts.application.prop;
class Sample21776_method
{
    boolean func(char[] paramArrayOfchar)
    {
        return false;
    }
}
