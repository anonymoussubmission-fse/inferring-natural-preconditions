    public Double createFromDouble(double d) {
        return Double.valueOf(d);
    }