    public static long parseTimeString(String paramString) {
        if (null == paramString)
            return -1L;
        long l = -1L;
        SimpleDateFormat[] arrayOfSimpleDateFormat = COMMON_TIME_FORMATS;
        int i = arrayOfSimpleDateFormat.length;
        byte b = 0;
        while (b < i) {
            SimpleDateFormat simpleDateFormat = arrayOfSimpleDateFormat[b];
            try {
                l = simpleDateFormat.parse(paramString).getTime();
                break;
            } catch (ParseException parseException) {
                b++;
            }
        }
        return l;
    }