    public RoundStatGenerator() {
        for (CombatantSide side : CombatantSide.values()) {
            this.health.put(side, new SimpleRoundStatistics("total health", "HP"));
            this.count.put(side, new SimpleRoundStatistics("number of combatants", "players"));
        }
    }