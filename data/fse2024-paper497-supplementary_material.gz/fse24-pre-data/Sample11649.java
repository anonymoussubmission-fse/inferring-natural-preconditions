    public WindowTracker(FollowAppAttributes attributes, JTabbedPane tabbedPane, SystemInterface systemInterface) {
        this.attributes = attributes;
        this.tabbedPane = tabbedPane;
        this.systemInterface = systemInterface;
    }