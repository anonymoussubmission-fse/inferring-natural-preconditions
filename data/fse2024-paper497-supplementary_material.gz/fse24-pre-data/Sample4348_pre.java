package com.mysql.cj.protocol.x;
class Sample17998_method
{
    boolean func()
    {
        return true;
    }
}
