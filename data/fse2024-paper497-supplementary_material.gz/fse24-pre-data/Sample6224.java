    public int process(Properties paramProperties, String[] paramArrayOfString, int paramInt, String paramString) {
        String str1 = getNameFor(paramProperties, paramArrayOfString, paramInt, paramString);
        String str2 = getValueFor(paramProperties, paramArrayOfString, paramInt, paramString);
        paramProperties.setProperty(str1, str2);
        return 1 + paramInt;
    }