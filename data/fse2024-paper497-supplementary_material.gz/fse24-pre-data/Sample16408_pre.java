package com.pmdesigns.jvc.tools;
import java.io.File;
class Sample3206_method
{
    static        boolean func(File f)
    {
        if (f == null)
            return true;
        return false;
    }
}
