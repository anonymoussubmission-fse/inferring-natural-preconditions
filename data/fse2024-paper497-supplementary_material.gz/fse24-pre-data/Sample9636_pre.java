package de.paragon.explorer.model;
class Sample18924_method
{
    boolean func(String newName)
    {
        return false;
    }
}
