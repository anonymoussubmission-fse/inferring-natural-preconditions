package org.asphodel.index;
class Sample4405_method
{
    boolean func(String uri)
    {
        return false;
    }
}
