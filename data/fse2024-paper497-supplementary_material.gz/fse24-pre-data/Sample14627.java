    public String getResourceManagerId() throws XAException {
        Object result;
        try {
            result = invoke(GETRESOURCEMANAGERID_23f8ced8, null, 603508440L);
        } catch (XAException exception) {
            throw exception;
        } catch (RemoteInvocationException exception) {
            throw exception;
        } catch (Throwable exception) {
            throw new RemoteInvocationException(exception);
        }
        return (String) result;
    }