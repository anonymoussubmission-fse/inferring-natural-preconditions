    public Core(ShellContext shellCtx, boolean withDefaultCommands, boolean debug) {
        this.cliParser = (CommandLineParser) new PosixParser();
        this.commands = new HashMap<String, Command>();
        this.aliases = new HashMap<String, String>();
        this.lastTrace = null;
        this.header = "Summa Generic Shell v1.6.5";
        this.prompt = "summa-shell> ";
        cmdComparator = new SimpleCompletor(new String[0]);
        if (shellCtx != null) {
            this.shellCtx = shellCtx;
        } else {
            this.shellCtx = new ShellContextImpl(createConsoleReader(), System.err, System.out, debug);
        }
        if (withDefaultCommands) {
            installCommand(new Help());
            installCommand(new Quit());
            installCommand(new Trace());
            installCommand(new Exec());
            installCommand(new Clear());
        }
    }