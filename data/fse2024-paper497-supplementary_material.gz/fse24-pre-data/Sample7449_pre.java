package com.lts.swing.treetable;
import javax.swing.tree.TreePath;
class Sample23026_method extends DefaultTreeTableModel
{
    boolean func(TreePath paramTreePath, Object paramObject)
    {
        javax.swing.tree.TreeModel var_a = getTreeModel();
        try {
            var_a.valueForPathChanged(paramTreePath, paramObject);
        } catch (          NullPointerException e) {
            return true;
        } catch (          ClassCastException e) {
            return true;
        }
        return false;
    }
}
