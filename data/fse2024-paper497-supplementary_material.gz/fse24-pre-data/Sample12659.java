    public String getMessage() {
        return super.getMessage() + ((this.payload == null) ? "" : this.payload.toString());
    }