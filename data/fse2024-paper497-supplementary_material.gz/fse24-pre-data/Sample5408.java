    public boolean isCompressing() {
        return compressing;
    }